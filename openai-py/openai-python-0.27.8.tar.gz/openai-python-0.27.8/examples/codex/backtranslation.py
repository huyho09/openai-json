# This code example has moved. You can now find it in the [OpenAI Cookbook](https://github.com/openai/openai-cookbook)
# at [examples/Backtranslation_of_SQL_queries](https://github.com/openai/openai-cookbook/blob/main/examples/Backtranslation_of_SQL_queries.py)
